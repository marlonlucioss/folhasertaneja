<?php get_header(); ?>

<?php hu_get_content( 'tmpl/archive-tmpl'); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>