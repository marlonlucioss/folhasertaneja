<?php get_header(); ?>

<?php hu_get_content( 'tmpl/index-tmpl'); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>